import { h, Fragment } from 'preact';
import Ladder from './components/ladder';
import Header from '../../../templates/components/header';
// import Main from './components/main';
import Title from '../../../templates/components/body';

import { signal } from '@preact/signals';


var board = null;
console.log(board)

function increase_snakes() {
    numsnakes += 1;
}

function decrease_snakes() {
    numsnakes -= 1;
}

function initialiseboard(size) {
    var line = [];
    var board = [];
    for (let i = 0; i < size; i++) {
        line.push({text : ""});
    }

    for (let i = 0; i < size; i++) {
        board.push(line);
    }
    return board
}

// function getboardl() {
//     let boardl = document.getElementById("boardinitialise");
//     board = initialiseboard(boardl.value);
// }

// function getboardl() {
//     let boardl = document.getElementById("boardinitialise");
//     board = initialiseboard(boardl.value);
// }

const things = signal(board);

const decider = signal('');

function todo() {
    things.value = decider.value;
    decider.value = '';
}


const getboardl = () => {
    let boardl = document.getElementById("boardinitialise");
    board = initialiseboard(boardl.value)
    decider.value = board
    console.log(decider.value)
    todo()
    console.log(things.value)
}

const App = () => <Fragment> 
<Header>
    boardgame
</Header>

<input type="text" id="boardinitialise" placeholder="a square of what length do you wish"> </input>
<button onclick = {getboardl}>enter length</button>

 <div class="board"> 
    {
        things.value ? things.value.map((row, idx) => {
                return row.map((cell, idxInner) => {
                            return <div class="board__cell">{`${idx}, ${idxInner}`}</div>;
                        })
            })
            : null
    }
    <Ladder height={400} width={100} angle1={15} angle2={0}/>
    <Ladder height={400} width={100} angle1={15} angle2={0}/>
    <Ladder height={400} width={100} angle1={15} angle2={0}/>
    
</div>




{/* { <div>
    <h1> `${things.value.map(board => board.text )}` </h1>
</div> } */}



</Fragment>
export default App; 
