
//import './modules/toggle';
//import './modules/app';
//import './modules/todo copy';
import './modules/todo copy twice'

// import(/* webpackChunkName: "toggle" */`./modules/toggle`).then(module => module.default());
// import(/* webpackChunkName: "validate" */`@stormid/validate`).then(module => module.default.init(VALIDATE.SELECTOR));