import { h, Fragment } from 'preact';
import { signal } from '@preact/signals';
import Header from './components/header';
import Ladder from './components/ladder';
import BOARD from './utils/board';

const SIZE = 19;

// const SNAKEPOS = 
const LADDERS = [
  {
    translate: [ 421.05263157894734, 210.52631578947367 ]
  },
  {
    translate: [ 0, 105.26315789473684 ],
  },
  {
    translate: [ 105.26315789473684, 736.8421052631578 ],
  },
  {
    translate: [ 421.05263157894734, 315.7894736842105 ],
  },
  {
    translate: [ 526.3157894736842, 736.8421052631578 ]
  }
]

/*
[
    {
        translation: ''
    }
]
*/
const App = () => <Fragment> 
    <div class="wrap">
        <Header>
            <h1 class="pagetitle">Lorenzo's Ladders </h1>
        </Header>
        <div class="board" style={`--size: ${SIZE}`}>
            <div class="board__grid">
                {
                    BOARD.map((row, idx) => {
                        return row.map((cell, idxInner) => {
                                    return <div class="board__cell">{`${idx}, ${idxInner}`}</div>;
                                })
                    })
                }
            </div>
            {
                LADDERS.map(ladder => <Ladder x1={ladder.translate[0]} y1={ladder.translate[1]} />)
            }
        </div>
    </div>
</Fragment>

export default App;